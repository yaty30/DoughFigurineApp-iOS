//
//  GlobalStatus.swift
//  MobileAssignment
//
//  Created by James Yip on 3/1/2022.
//

import Foundation

struct currentUserData {
    static var currentUser = ""
    static var loginDate = ""
    static var loginTime = ""
    static var loginToken = ""
    static var logoutDate = ""
    static var logoutTime = ""
}


